package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.CityMaster;


public interface CityService {
	public  Boolean addCityService(CityMaster cityMaster);
	public  Boolean updateCityService(CityMaster cityMaster);
	public  Boolean deleteCityService(CityMaster cityMaster);
	public CityMaster getCityService(int cId);
	public List<CityMaster> getAllCityService();
}
