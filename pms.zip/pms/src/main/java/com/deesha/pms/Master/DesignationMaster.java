package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tbldesignation")
public class DesignationMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)

private Integer DesId;
private String DesName;
private String DesDescription;
public Integer getDesId() {
	return DesId;
}
public void setDesId(Integer desId) {
	DesId = desId;
}
public String getDesName() {
	return DesName;
}
public void setDesName(String desName) {
	DesName = desName;
}
public String getDesDescription() {
	return DesDescription;
}
public void setDesDescription(String desDescription) {
	DesDescription = desDescription;
}
public DesignationMaster() {
	super();
}
public DesignationMaster(Integer desId, String desName, String desDescription) {
	super();
	DesId = desId;
	DesName = desName;
	DesDescription = desDescription;
}
@Override
public String toString() {
	return "DesignationMaster [DesId=" + DesId + ", DesName=" + DesName + ", DesDescription=" + DesDescription + "]";
}


}
