package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.PublicHolidayCalendarMaster;

public interface PublicHolidayCalendarService {
	public  Boolean addPublicHolidayCalendarService(PublicHolidayCalendarMaster publicholidaycalendarMaster);
	public  Boolean updatePublicHolidayCalendarService(PublicHolidayCalendarMaster publicholidaycalendarMaster);
	public  Boolean deletePublicHolidayCalendarService(PublicHolidayCalendarMaster publicholidaycalendarMaster);
	public PublicHolidayCalendarMaster getPublicHolidayCalendarService(int pId);
	public List<PublicHolidayCalendarMaster> getAllPublicHolidayCalendarService();
}
