package com.deesha.pms.ServiceImpl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.CityDAO;
import com.deesha.pms.Master.CityMaster;
import com.deesha.pms.Service.CityService;


@Service
public class CityServiceImpl  implements CityService{
	
	@Autowired
	    private CityDAO cityDao;
	 
	    public Boolean addCityService(CityMaster cityMaster) {

	        try{
	        	cityDao.save(cityMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateCityService(CityMaster cityMaster) {

			 try{
				 cityDao.save(cityMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteCityService(CityMaster cityMaster) {
			  try{
				  cityDao.delete(cityMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public CityMaster getCityService(int cId) {
			try{
				CityMaster cityMaster = cityDao.findById(cId).get();
	            return cityMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<CityMaster> getAllCityService() {
			try{
	        	List<CityMaster> all = (List<CityMaster>) cityDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}
