package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.EmployeeDeductionMaster;

public interface EmployeeDeductionService {
	public  Boolean addEmployeeDeductionService(EmployeeDeductionMaster employeedeductionMaster);
	public  Boolean updateEmployeeDeductionService(EmployeeDeductionMaster employeedeductionMaster);
	public  Boolean deleteEmployeeDeductionService(EmployeeDeductionMaster employeedeductionMaster);
	public EmployeeDeductionMaster getEmployeeDeductionService(int eId);
	public List<EmployeeDeductionMaster> getAllEmployeeDeductionService();
}
