package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tbldepartment")
public class DepartmentMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer deptId;
private String DeptName;
private String DeptDesciption;
public Integer getDeptId() {
	return deptId;
}
public void setDeptId(Integer deptId) {
	this.deptId = deptId;
}
public String getDeptName() {
	return DeptName;
}
public void setDeptName(String deptName) {
	DeptName = deptName;
}
public String getDeptDesciption() {
	return DeptDesciption;
}
public void setDeptDesciption(String deptDesciption) {
	DeptDesciption = deptDesciption;
}
public DepartmentMaster() {
	super();
}
public DepartmentMaster(Integer deptId, String deptName, String deptDesciption) {
	super();
	this.deptId = deptId;
	DeptName = deptName;
	DeptDesciption = deptDesciption;
}
@Override
public String toString() {
	return "DepartmentMaster [deptId=" + deptId + ", DeptName=" + DeptName + ", DeptDesciption=" + DeptDesciption + "]";
}

}
