package com.deesha.pms.DAO;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.deesha.pms.Master.CountryMaster;
@Repository
public interface CountryDAO extends CrudRepository<CountryMaster,Integer> {

}
