package com.deesha.pms.DAO;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.deesha.pms.Master.EmployeeMaster;
@Repository
public interface EmployeeDAO extends CrudRepository<EmployeeMaster,Integer> {

}
