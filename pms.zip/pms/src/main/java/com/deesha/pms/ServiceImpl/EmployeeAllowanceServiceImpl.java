package com.deesha.pms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.EmployeeAllowanceDAO;
import com.deesha.pms.Master.EmployeeAllowanceMaster;
import com.deesha.pms.Service.EmployeeAllowanceService;


@Service
public class EmployeeAllowanceServiceImpl  implements EmployeeAllowanceService{
	
	@Autowired
	    private EmployeeAllowanceDAO employeeallowanceDao;
	 
	    public Boolean addEmployeeAllowanceService(EmployeeAllowanceMaster employeeallowanceMaster) {

	        try{
	        	employeeallowanceDao.save(employeeallowanceMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateEmployeeAllowanceService(EmployeeAllowanceMaster employeeallowanceMaster) {

			 try{
				 employeeallowanceDao.save(employeeallowanceMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteEmployeeAllowanceService(EmployeeAllowanceMaster employeeallowanceMaster) {
			  try{
				  employeeallowanceDao.delete(employeeallowanceMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public EmployeeAllowanceMaster getEmployeeAllowanceService(int eId) {
			try{
				EmployeeAllowanceMaster employeeallowanceMaster = employeeallowanceDao.findById(eId).get();
	            return employeeallowanceMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<EmployeeAllowanceMaster> getAllEmployeeAllowanceService() {
			try{
	        	List<EmployeeAllowanceMaster> all = (List<EmployeeAllowanceMaster>) employeeallowanceDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}