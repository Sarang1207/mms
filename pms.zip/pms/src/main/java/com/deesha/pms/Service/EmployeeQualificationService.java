package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.EmployeeQualificationMaster;

public interface EmployeeQualificationService {
	public  Boolean addEmployeeQualificationService(EmployeeQualificationMaster employeequalificationMaster);
	public  Boolean updateEmployeeQualificationService(EmployeeQualificationMaster employeequalificationMaster);
	public  Boolean deleteEmployeeQualificationService(EmployeeQualificationMaster employeequalificationMaster);
	public EmployeeQualificationMaster getEmployeeQualificationService(int eId);
	public List<EmployeeQualificationMaster> getAllEmployeeQualificationService();
}
