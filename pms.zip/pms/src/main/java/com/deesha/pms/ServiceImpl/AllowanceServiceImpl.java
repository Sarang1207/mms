package com.deesha.pms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.AllowanceDAO;
import com.deesha.pms.Master.AllowanceMaster;
import com.deesha.pms.Service.AllowanceService;


@Service
public class AllowanceServiceImpl  implements AllowanceService{
	
	@Autowired
	    private AllowanceDAO allowanceDao;
	 
	    public Boolean addAllowanceService(AllowanceMaster allowanceMaster) {

	        try{
	        	allowanceDao.save(allowanceMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateAllowanceService(AllowanceMaster allowanceMaster) {

			 try{
				 allowanceDao.save(allowanceMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteAllowanceService(AllowanceMaster allowanceMaster) {
			  try{
				  allowanceDao.delete(allowanceMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public AllowanceMaster getAllowanceService(int aId) {
			try{
				AllowanceMaster allowanceMaster = allowanceDao.findById(aId).get();
	            return allowanceMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<AllowanceMaster> getAllAllowanceService() {
			try{
	        	List<AllowanceMaster> all = (List<AllowanceMaster>) allowanceDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}