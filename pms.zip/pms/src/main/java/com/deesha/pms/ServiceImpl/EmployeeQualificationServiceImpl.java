package com.deesha.pms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.EmployeeQualificationDAO;
import com.deesha.pms.Master.EmployeeQualificationMaster;
import com.deesha.pms.Service.EmployeeQualificationService;


@Service
public class EmployeeQualificationServiceImpl  implements EmployeeQualificationService{
	
	@Autowired
	    private EmployeeQualificationDAO employeequalificationDao;
	 
	    public Boolean addEmployeeQualificationService(EmployeeQualificationMaster employeequalificationMaster) {

	        try{
	        	employeequalificationDao.save(employeequalificationMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateEmployeeQualificationService(EmployeeQualificationMaster employeequalificationMaster) {

			 try{
				 employeequalificationDao.save(employeequalificationMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteEmployeeQualificationService(EmployeeQualificationMaster employeequalificationMaster) {
			  try{
				  employeequalificationDao.delete(employeequalificationMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public EmployeeQualificationMaster getEmployeeQualificationService(int eId) {
			try{
				EmployeeQualificationMaster employeequalificationMaster = employeequalificationDao.findById(eId).get();
	            return employeequalificationMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<EmployeeQualificationMaster> getAllEmployeeQualificationService() {
			try{
	        	List<EmployeeQualificationMaster> all = (List<EmployeeQualificationMaster>) employeequalificationDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}