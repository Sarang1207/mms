package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tblemployee")
public class EmployeeMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer empId;
private String empName;
private String EmpMobile;
private String EmpAltMobile;
private String EmpAddress;
private String EmpCityId;  
private String EmpMail;
private String EmpRole;
private String EmpDOB;
private String DeptId;
private String EmpRoleId;
private String EmpDesId;
private String EmpBasicSalary;
public Integer getEmpId() {
	return empId;
}
public void setEmpId(Integer empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public String getEmpMobile() {
	return EmpMobile;
}
public void setEmpMobile(String empMobile) {
	EmpMobile = empMobile;
}
public String getEmpAltMobile() {
	return EmpAltMobile;
}
public void setEmpAltMobile(String empAltMobile) {
	EmpAltMobile = empAltMobile;
}
public String getEmpAddress() {
	return EmpAddress;
}
public void setEmpAddress(String empAddress) {
	EmpAddress = empAddress;
}
public String getEmpCityId() {
	return EmpCityId;
}
public void setEmpCityId(String empCityId) {
	EmpCityId = empCityId;
}
public String getEmpMail() {
	return EmpMail;
}
public void setEmpMail(String empMail) {
	EmpMail = empMail;
}
public String getEmpRole() {
	return EmpRole;
}
public void setEmpRole(String empRole) {
	EmpRole = empRole;
}
public String getEmpDOB() {
	return EmpDOB;
}
public void setEmpDOB(String empDOB) {
	EmpDOB = empDOB;
}
public String getDeptId() {
	return DeptId;
}
public void setDeptId(String deptId) {
	DeptId = deptId;
}
public String getEmpRoleId() {
	return EmpRoleId;
}
public void setEmpRoleId(String empRoleId) {
	EmpRoleId = empRoleId;
}
public String getEmpDesId() {
	return EmpDesId;
}
public void setEmpDesId(String empDesId) {
	EmpDesId = empDesId;
}
public String getEmpBasicSalary() {
	return EmpBasicSalary;
}
public void setEmpBasicSalary(String empBasicSalary) {
	EmpBasicSalary = empBasicSalary;
}
public EmployeeMaster() {
	super();
}
public EmployeeMaster(Integer empId, String empName, String empMobile, String empAltMobile, String empAddress,
		String empCityId, String empMail, String empRole, String empDOB, String deptId, String empRoleId,
		String empDesId, String empBasicSalary) {
	super();
	this.empId = empId;
	this.empName = empName;
	EmpMobile = empMobile;
	EmpAltMobile = empAltMobile;
	EmpAddress = empAddress;
	EmpCityId = empCityId;
	EmpMail = empMail;
	EmpRole = empRole;
	EmpDOB = empDOB;
	DeptId = deptId;
	EmpRoleId = empRoleId;
	EmpDesId = empDesId;
	EmpBasicSalary = empBasicSalary;
}
@Override
public String toString() {
	return "EmployeeMaster [empId=" + empId + ", empName=" + empName + ", EmpMobile=" + EmpMobile + ", EmpAltMobile="
			+ EmpAltMobile + ", EmpAddress=" + EmpAddress + ", EmpCityId=" + EmpCityId + ", EmpMail=" + EmpMail
			+ ", EmpRole=" + EmpRole + ", EmpDOB=" + EmpDOB + ", DeptId=" + DeptId + ", EmpRoleId=" + EmpRoleId
			+ ", EmpDesId=" + EmpDesId + ", EmpBasicSalary=" + EmpBasicSalary + "]";
}


}
