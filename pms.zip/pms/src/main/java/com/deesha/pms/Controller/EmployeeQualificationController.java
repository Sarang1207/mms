package com.deesha.pms.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.EmployeeQualificationMaster;
import com.deesha.pms.Service.EmployeeQualificationService;

@RestController
@CrossOrigin("*")
public class EmployeeQualificationController {
	 @Autowired
	    private EmployeeQualificationService employeequalificationService;

	    @PostMapping
	    @RequestMapping(value="AddEmployeeQualificationDetails")
	    private ResponseEntity addEmployeeQualification(@RequestBody EmployeeQualificationMaster employeequalificationMaster) {
	    	System.out.println(employeequalificationMaster.toString());
	        Boolean flag = employeequalificationService.addEmployeeQualificationService(employeequalificationMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdateEmployeeQualificationDetails")
	    private ResponseEntity updateEmployeeQualification(@RequestBody EmployeeQualificationMaster employeequalificationMaster) {
	        Boolean flag = employeequalificationService.updateEmployeeQualificationService(employeequalificationMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeleteEmployeeQualificationDetails")
	    private ResponseEntity deleteEmployeeQualification(@RequestBody EmployeeQualificationMaster employeequalificationMaster) {
	        Boolean flag = employeequalificationService.deleteEmployeeQualificationService(employeequalificationMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getEmployeeQualificationDetails")
	    private ResponseEntity getEmployeeQualification(@RequestBody int eId) {
	    	EmployeeQualificationMaster employeequalificationMaster = employeequalificationService.getEmployeeQualificationService(eId);
	        if (employeequalificationMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllEmployeeQualificationDetails")
	    private List<EmployeeQualificationMaster> getAllEmployeeQualification() {
	    	List<EmployeeQualificationMaster> lstemployeequalificationMaster = employeequalificationService.getAllEmployeeQualificationService();
	    	System.out.println();
	        if (lstemployeequalificationMaster != null)
	          return lstemployeequalificationMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}
