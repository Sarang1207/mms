package com.deesha.pms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.DeductionMaster;
import com.deesha.pms.Service.DeductionService;

@RestController
@CrossOrigin("*")
public class DeductionController {
	 @Autowired
	    private DeductionService deductionService;

	    @PostMapping
	    @RequestMapping(value="AddDeductionDetails")
	    private ResponseEntity addDeduction(@RequestBody DeductionMaster deductionMaster) {
	    	System.out.println(deductionMaster.toString());
	        Boolean flag = deductionService.addDeductionService(deductionMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdateDeductionDetails")
	    private ResponseEntity updateDeduction(@RequestBody DeductionMaster deductionMaster) {
	        Boolean flag = deductionService.updateDeductionService(deductionMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeleteDeductionDetails")
	    private ResponseEntity deleteDeduction(@RequestBody DeductionMaster deductionMaster) {
	        Boolean flag = deductionService.deleteDeductionService(deductionMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getDeductionDetails")
	    private ResponseEntity getDeduction(@RequestBody int dId) {
	    	DeductionMaster deductionMaster = deductionService.getDeductionService(dId);
	        if (deductionMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllDeductionDetails")
	    private List<DeductionMaster> getAllDeduction() {
	    	List<DeductionMaster> lstdeductionMaster = deductionService.getAllDeductionService();
	    	System.out.println();
	        if (lstdeductionMaster != null)
	          return lstdeductionMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}
