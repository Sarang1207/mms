package com.deesha.pms.ServiceImpl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.StateDAO;
import com.deesha.pms.Master.StateMaster;
import com.deesha.pms.Service.StateService;


@Service
public class StateServiceImpl  implements StateService{
	
	@Autowired
	    private StateDAO stateDao;
	 
	    public Boolean addStateService(StateMaster stateMaster) {

	        try{
	        	stateDao.save(stateMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateStateService(StateMaster stateMaster) {

			 try{
				 stateDao.save(stateMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteStateService(StateMaster stateMaster) {
			  try{
				  stateDao.delete(stateMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public StateMaster getStateService(int sId) {
			try{
				StateMaster stateMaster = stateDao.findById(sId).get();
	            return stateMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<StateMaster> getAllStateService() {
			try{
	        	List<StateMaster> all = (List<StateMaster>) stateDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}