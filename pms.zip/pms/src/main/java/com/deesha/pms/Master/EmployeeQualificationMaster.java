package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tblemployeequalification")
public class EmployeeQualificationMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer EmpId;
private Integer QualId;
private String Qual_University; 
private String QualificationYear;
private String Qual_GradePercentage;
public Integer getEmpId() {
	return EmpId;
}
public void setEmpId(Integer empId) {
	EmpId = empId;
}
public Integer getQualId() {
	return QualId;
}
public void setQualId(Integer qualId) {
	QualId = qualId;
}
public String getQual_University() {
	return Qual_University;
}
public void setQual_University(String qual_University) {
	Qual_University = qual_University;
}
public String getQualificationYear() {
	return QualificationYear;
}
public void setQualificationYear(String qualificationYear) {
	QualificationYear = qualificationYear;
}
public String getQual_GradePercentage() {
	return Qual_GradePercentage;
}
public void setQual_GradePercentage(String qual_GradePercentage) {
	Qual_GradePercentage = qual_GradePercentage;
}
public EmployeeQualificationMaster() {
	super();
}
public EmployeeQualificationMaster(Integer empId, Integer qualId, String qual_University, String qualificationYear,
		String qual_GradePercentage) {
	super();
	EmpId = empId;
	QualId = qualId;
	Qual_University = qual_University;
	QualificationYear = qualificationYear;
	Qual_GradePercentage = qual_GradePercentage;
}
@Override
public String toString() {
	return "EmployeeQualificationMaster [EmpId=" + EmpId + ", QualId=" + QualId + ", Qual_University=" + Qual_University
			+ ", QualificationYear=" + QualificationYear + ", Qual_GradePercentage=" + Qual_GradePercentage + "]";
}


}
