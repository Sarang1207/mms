package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.EmployeeMaster;

public interface EmployeeService {
	public  Boolean addEmployeeService(EmployeeMaster employeeMaster);
	public  Boolean updateEmployeeService(EmployeeMaster employeeMaster);
	public  Boolean deleteEmployeeService(EmployeeMaster employeeMaster);
	public EmployeeMaster getEmployeeService(int eId);
	public List<EmployeeMaster> getAllEmployeeService();
}
