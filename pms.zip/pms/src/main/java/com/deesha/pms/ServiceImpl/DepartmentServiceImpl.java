package com.deesha.pms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.DepartmentDAO;
import com.deesha.pms.Master.DepartmentMaster;
import com.deesha.pms.Service.DepartmentService;


@Service
public class DepartmentServiceImpl  implements DepartmentService{
	
	@Autowired
	    private DepartmentDAO departmentDao;
	 
	    public Boolean addDepartmentService(DepartmentMaster departmentMaster) {

	        try{
	        	departmentDao.save(departmentMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateDepartmentService(DepartmentMaster departmentMaster) {

			 try{
				 departmentDao.save(departmentMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteDepartmentService(DepartmentMaster departmentMaster) {
			  try{
				  departmentDao.delete(departmentMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public DepartmentMaster getDepartmentService(int dId) {
			try{
				DepartmentMaster departmentMaster = departmentDao.findById(dId).get();
	            return departmentMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<DepartmentMaster> getAllDepartmentService() {
			try{
	        	List<DepartmentMaster> all = (List<DepartmentMaster>) departmentDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}