package com.deesha.pms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.LeaveRecordDAO;
import com.deesha.pms.Master.LeaveRecordMaster;
import com.deesha.pms.Service.LeaveRecordService;


@Service
public class LeaveRecordServiceImpl  implements LeaveRecordService{
	
	@Autowired
	    private LeaveRecordDAO leaverecordDao;
	 
	    public Boolean addLeaveRecordService(LeaveRecordMaster leaverecordMaster) {

	        try{
	        	leaverecordDao.save(leaverecordMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateLeaveRecordService(LeaveRecordMaster leaverecordMaster) {

			 try{
				 leaverecordDao.save(leaverecordMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteLeaveRecordService(LeaveRecordMaster leaverecordMaster) {
			  try{
				  leaverecordDao.delete(leaverecordMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public LeaveRecordMaster getLeaveRecordService(int lId) {
			try{
				LeaveRecordMaster leaverecordMaster = leaverecordDao.findById(lId).get();
	            return leaverecordMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<LeaveRecordMaster> getAllLeaveRecordService() {
			try{
	        	List<LeaveRecordMaster> all = (List<LeaveRecordMaster>) leaverecordDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}