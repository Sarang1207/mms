package com.deesha.pms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.LeaveRecordMaster;
import com.deesha.pms.Service.LeaveRecordService;

@RestController
@CrossOrigin("*")
public class LeaveRecordController {
	 @Autowired
	    private LeaveRecordService leaverecordService;

	    @PostMapping
	    @RequestMapping(value="AddLeaveRecordDetails")
	    private ResponseEntity addLeaveRecord(@RequestBody LeaveRecordMaster leaverecordMaster) {
	    	System.out.println(leaverecordMaster.toString());
	        Boolean flag = leaverecordService.addLeaveRecordService(leaverecordMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdateLeaveRecordDetails")
	    private ResponseEntity updateLeaveRecord(@RequestBody LeaveRecordMaster leaverecordMaster) {
	        Boolean flag = leaverecordService.updateLeaveRecordService(leaverecordMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeleteLeaveRecordDetails")
	    private ResponseEntity deleteLeaveRecord(@RequestBody LeaveRecordMaster leaverecordMaster) {
	        Boolean flag = leaverecordService.deleteLeaveRecordService(leaverecordMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getLeaveRecordDetails")
	    private ResponseEntity getLeaveRecord(@RequestBody int lId) {
	    	LeaveRecordMaster leaverecordMaster =leaverecordService.getLeaveRecordService(lId);
	        if (leaverecordMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllLeaveRecordDetails")
	    private List<LeaveRecordMaster> getAllLeaveRecord() {
	    	List<LeaveRecordMaster> lstleaverecordMaster = leaverecordService.getAllLeaveRecordService();
	    	System.out.println();
	        if (lstleaverecordMaster != null)
	          return lstleaverecordMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}
