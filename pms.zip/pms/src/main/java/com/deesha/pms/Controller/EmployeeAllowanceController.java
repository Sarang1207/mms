package com.deesha.pms.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.EmployeeAllowanceMaster;
import com.deesha.pms.Service.EmployeeAllowanceService;

@RestController
@CrossOrigin("*")
public class EmployeeAllowanceController {
	 @Autowired
	    private EmployeeAllowanceService employeeallowanceService;

	    @PostMapping
	    @RequestMapping(value="AddEmployeeAllowanceDetails")
	    private ResponseEntity addEmployeeAllowance(@RequestBody EmployeeAllowanceMaster employeeallowanceMaster) {
	    	System.out.println(employeeallowanceMaster.toString());
	        Boolean flag = employeeallowanceService.addEmployeeAllowanceService(employeeallowanceMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdateEmployeeAllowanceDetails")
	    private ResponseEntity updateEmployeeAllowance(@RequestBody EmployeeAllowanceMaster employeeallowanceMaster) {
	        Boolean flag = employeeallowanceService.updateEmployeeAllowanceService(employeeallowanceMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeleteEmployeeAllowanceDetails")
	    private ResponseEntity deleteEmployeeAllowance(@RequestBody EmployeeAllowanceMaster employeeallowanceMaster) {
	        Boolean flag = employeeallowanceService.deleteEmployeeAllowanceService(employeeallowanceMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getEmployeeAllowanceDetails")
	    private ResponseEntity getEmployeeAllowance(@RequestBody int eId) {
	    	EmployeeAllowanceMaster employeeallowanceMaster = employeeallowanceService.getEmployeeAllowanceService(eId);
	        if (employeeallowanceMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllEmployeeAllowanceDetails")
	    private List<EmployeeAllowanceMaster> getAllEmployeeAllowance() {
	    	List<EmployeeAllowanceMaster> lstemployeeallowanceMaster = employeeallowanceService.getAllEmployeeAllowanceService();
	    	System.out.println();
	        if (lstemployeeallowanceMaster != null)
	          return lstemployeeallowanceMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}
