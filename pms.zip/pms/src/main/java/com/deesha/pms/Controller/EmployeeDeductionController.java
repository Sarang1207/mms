package com.deesha.pms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.EmployeeDeductionMaster;
import com.deesha.pms.Service.EmployeeDeductionService;

@RestController
@CrossOrigin("*")
public class EmployeeDeductionController {
	 @Autowired
	    private EmployeeDeductionService employeedeductionService;

	    @PostMapping
	    @RequestMapping(value="AddEmployeeDeductionDetails")
	    private ResponseEntity addEmployeeDeduction(@RequestBody EmployeeDeductionMaster employeedeductionMaster) {
	    	System.out.println(employeedeductionMaster.toString());
	        Boolean flag = employeedeductionService.addEmployeeDeductionService(employeedeductionMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdateEmployeeDeductionDetails")
	    private ResponseEntity updateEmployeeDeduction(@RequestBody EmployeeDeductionMaster employeedeductionMaster) {
	        Boolean flag = employeedeductionService.updateEmployeeDeductionService(employeedeductionMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeleteEmployeeDeductionDetails")
	    private ResponseEntity deleteEmployeeDeduction(@RequestBody EmployeeDeductionMaster employeedeductionMaster) {
	        Boolean flag = employeedeductionService.deleteEmployeeDeductionService(employeedeductionMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getEmployeeDeductionDetails")
	    private ResponseEntity getEmployeeDeduction(@RequestBody int eId) {
	    	EmployeeDeductionMaster employeedeductionMaster = employeedeductionService.getEmployeeDeductionService(eId);
	        if (employeedeductionMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllEmployeeDeductionDetails")
	    private List<EmployeeDeductionMaster> getAllEmployeeDeduction() {
	    	List<EmployeeDeductionMaster> lstemployeedeductionMaster = employeedeductionService.getAllEmployeeDeductionService();
	    	System.out.println();
	        if (lstemployeedeductionMaster != null)
	          return lstemployeedeductionMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}
