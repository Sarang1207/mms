package com.deesha.pms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.DeductionDAO;
import com.deesha.pms.Master.DeductionMaster;
import com.deesha.pms.Service.DeductionService;


@Service
public class DeductionServiceImpl  implements DeductionService{
	
	@Autowired
	    private DeductionDAO deductionDao;
	 
	    public Boolean addDeductionService(DeductionMaster deductionMaster) {

	        try{
	        	deductionDao.save(deductionMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateDeductionService(DeductionMaster deductionMaster) {

			 try{
				 deductionDao.save(deductionMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteDeductionService(DeductionMaster deductionMaster) {
			  try{
				  deductionDao.delete(deductionMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public DeductionMaster getDeductionService(int dId) {
			try{
				DeductionMaster deductionMaster = deductionDao.findById(dId).get();
	            return deductionMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<DeductionMaster> getAllDeductionService() {
			try{
	        	List<DeductionMaster> all = (List<DeductionMaster>) deductionDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}