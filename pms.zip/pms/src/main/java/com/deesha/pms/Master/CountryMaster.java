package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tblcountry")
public class CountryMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer CountryId;
private String CountryName;
private String CountryDescription;
public Integer getCountryId() {
	return CountryId;
}
public void setCountryId(Integer countryId) {
	CountryId = countryId;
}
public String getCountryName() {
	return CountryName;
}
public void setCountryName(String countryName) {
	CountryName = countryName;
}
public String getCountryDescription() {
	return CountryDescription;
}
public void setCountryDescription(String countryDescription) {
	CountryDescription = countryDescription;
}
public CountryMaster() {
	super();
}
public CountryMaster(Integer countryId, String countryName, String countryDescription) {
	super();
	CountryId = countryId;
	CountryName = countryName;
	CountryDescription = countryDescription;
}
@Override
public String toString() {
	return "CountryMaster [CountryId=" + CountryId + ", CountryName=" + CountryName + ", CountryDescription="
			+ CountryDescription + "]";
}


}
