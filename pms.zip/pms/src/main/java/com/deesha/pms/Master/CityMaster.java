package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tblcity")
public class CityMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer CityId;
private String CityName;
private String StateId;
private String CityPincode;
private String CityDescription;
public Integer getCityId() {
	return CityId;
}
public void setCityId(Integer cityId) {
	CityId = cityId;
}
public String getCityName() {
	return CityName;
}
public void setCityName(String cityName) {
	CityName = cityName;
}
public String getStateId() {
	return StateId;
}
public void setStateId(String stateId) {
	StateId = stateId;
}
public String getCityPincode() {
	return CityPincode;
}
public void setCityPincode(String cityPincode) {
	CityPincode = cityPincode;
}
public String getCityDescription() {
	return CityDescription;
}
public void setCityDescription(String cityDescription) {
	CityDescription = cityDescription;
}
public CityMaster() {
	super();
}
public CityMaster(Integer cityId, String cityName, String stateId, String cityPincode, String cityDescription) {
	super();
	CityId = cityId;
	CityName = cityName;
	StateId = stateId;
	CityPincode = cityPincode;
	CityDescription = cityDescription;
}
@Override
public String toString() {
	return "CityMaster [CityId=" + CityId + ", CityName=" + CityName + ", StateId=" + StateId + ", CityPincode="
			+ CityPincode + ", CityDescription=" + CityDescription + "]";
}



}
