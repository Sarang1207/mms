package com.deesha.pms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.DepartmentMaster;
import com.deesha.pms.Service.DepartmentService;


@RestController
@CrossOrigin("*")
public class DepartmentController {
	 @Autowired
	    private DepartmentService departmentService;

	    @PostMapping
	    @RequestMapping(value="AddDepartmentDetails")
	    private ResponseEntity addDepartment(@RequestBody DepartmentMaster departmentMaster) {
	    	System.out.println(departmentMaster.toString());
	        Boolean flag = departmentService.addDepartmentService(departmentMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdateDepartmentDetails")
	    private ResponseEntity updateDepartment(@RequestBody DepartmentMaster departmentMaster) {
	        Boolean flag = departmentService.updateDepartmentService(departmentMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeleteDepartmentDetails")
	    private ResponseEntity deleteDepartment(@RequestBody DepartmentMaster departmentMaster) {
	        Boolean flag = departmentService.deleteDepartmentService(departmentMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getDepartmentDetails")
	    private ResponseEntity getDepartment(@RequestBody int dId) {
	    	DepartmentMaster departmentMaster = departmentService.getDepartmentService(dId);
	        if (departmentMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllDepartmentDetails")
	    private List<DepartmentMaster> getAllDepartment() {
	    	List<DepartmentMaster> lstdepartmentMaster = departmentService.getAllDepartmentService();
	    	System.out.println();
	        if (lstdepartmentMaster != null)
	          return lstdepartmentMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}
