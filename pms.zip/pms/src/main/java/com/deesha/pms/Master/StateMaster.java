package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tblstate")
public class StateMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer stateId;
private String stateName;
private String countryId;
private String stateDescription;
public Integer getStateId() {
	return stateId;
}
public void setStateId(Integer stateId) {
	this.stateId = stateId;
}
public String getStateName() {
	return stateName;
}
public void setStateName(String stateName) {
	this.stateName = stateName;
}
public String getCountryId() {
	return countryId;
}
public void setCountryId(String countryId) {
	this.countryId = countryId;
}
public String getStateDescription() {
	return stateDescription;
}
public void setStateDescription(String stateDescription) {
	this.stateDescription = stateDescription;
}
public StateMaster() {
	super();
}
public StateMaster(Integer stateId, String stateName, String countryId, String stateDescription) {
	super();
	this.stateId = stateId;
	this.stateName = stateName;
	this.countryId = countryId;
	this.stateDescription = stateDescription;
}
@Override
public String toString() {
	return "StateMaster [stateId=" + stateId + ", stateName=" + stateName + ", countryId=" + countryId
			+ ", stateDescription=" + stateDescription + "]";
}


}
