package com.deesha.pms.Service;

import java.util.List;


import com.deesha.pms.Master.DesignationMaster;

public interface DesignationService {
	public  Boolean addDesignationService(DesignationMaster designationMaster);
	public  Boolean updateDesignationService(DesignationMaster designationMaster);
	public  Boolean deleteDesignationService(DesignationMaster designationMaster);
	public DesignationMaster getDesignationService(int dId);
	public List<DesignationMaster> getAllDesignationService();
}
