package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tblpublicholidaycalendar")
public class PublicHolidayCalendarMaster {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer phid;
	private String phname;
	private String phdate;
	private String phdescription;
	public Integer getPhid() {
		return phid;
	}
	public void setPhid(Integer phid) {
		this.phid = phid;
	}
	public String getPhname() {
		return phname;
	}
	public void setPhname(String phname) {
		this.phname = phname;
	}
	public String getPhdate() {
		return phdate;
	}
	public void setPhdate(String phdate) {
		this.phdate = phdate;
	}
	public String getPhdescription() {
		return phdescription;
	}
	public void setPhdescription(String phdescription) {
		this.phdescription = phdescription;
	}
	public PublicHolidayCalendarMaster() {
		super();
	}
	public PublicHolidayCalendarMaster(Integer phid, String phname, String phdate, String phdescription) {
		super();
		this.phid = phid;
		this.phname = phname;
		this.phdate = phdate;
		this.phdescription = phdescription;
	}
	@Override
	public String toString() {
		return "PublicHolidayCalendarMaster [phid=" + phid + ", phname=" + phname + ", phdate=" + phdate
				+ ", phdescription=" + phdescription + "]";
	}
	
	
}
