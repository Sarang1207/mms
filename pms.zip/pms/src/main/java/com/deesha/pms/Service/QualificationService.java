package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.QualificationMaster;


public interface QualificationService {
	public  Boolean addQualificationService(QualificationMaster qualificationMaster);
	public  Boolean updateQualificationService(QualificationMaster qualificationMaster);
	public  Boolean deleteQualificationService(QualificationMaster qualificationMaster);
	public QualificationMaster getQualificationService(int qId);
	public List<QualificationMaster> getAllQualificationService();
}
