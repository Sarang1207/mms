package com.deesha.pms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.PublicHolidayCalendarDAO;
import com.deesha.pms.Master.PublicHolidayCalendarMaster;
import com.deesha.pms.Service.PublicHolidayCalendarService;


@Service
public class PublicHolidayCalendarServiceImpl  implements PublicHolidayCalendarService{
	
	@Autowired
	    private PublicHolidayCalendarDAO publicholidaycalendarDao;
	 
	    public Boolean addPublicHolidayCalendarService(PublicHolidayCalendarMaster publicholidaycalendarMaster) {

	        try{
	        	publicholidaycalendarDao.save(publicholidaycalendarMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updatePublicHolidayCalendarService(PublicHolidayCalendarMaster publicholidaycalendarMaster) {

			 try{
				 publicholidaycalendarDao.save(publicholidaycalendarMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deletePublicHolidayCalendarService(PublicHolidayCalendarMaster publicholidaycalendarMaster) {
			  try{
				  publicholidaycalendarDao.delete(publicholidaycalendarMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public PublicHolidayCalendarMaster getPublicHolidayCalendarService(int pId) {
			try{
				PublicHolidayCalendarMaster publicholidaycalendarMaster = publicholidaycalendarDao.findById(pId).get();
	            return publicholidaycalendarMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<PublicHolidayCalendarMaster> getAllPublicHolidayCalendarService() {
			try{
	        	List<PublicHolidayCalendarMaster> all = (List<PublicHolidayCalendarMaster>) publicholidaycalendarDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}