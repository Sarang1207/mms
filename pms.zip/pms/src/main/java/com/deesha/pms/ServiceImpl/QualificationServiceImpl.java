package com.deesha.pms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.QualificationDAO;
import com.deesha.pms.Master.QualificationMaster;
import com.deesha.pms.Service.QualificationService;


@Service
public class QualificationServiceImpl  implements QualificationService{
	
	@Autowired
	    private QualificationDAO qualificationDao;
	 
	    public Boolean addQualificationService(QualificationMaster qualificationMaster) {

	        try{
	        	qualificationDao.save(qualificationMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateQualificationService(QualificationMaster qualificationMaster) {

			 try{
				 qualificationDao.save(qualificationMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteQualificationService(QualificationMaster qualificationMaster) {
			  try{
				  qualificationDao.delete(qualificationMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public QualificationMaster getQualificationService(int qId) {
			try{
				QualificationMaster qualificationMaster = qualificationDao.findById(qId).get();
	            return qualificationMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<QualificationMaster> getAllQualificationService() {
			try{
	        	List<QualificationMaster> all = (List<QualificationMaster>) qualificationDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}