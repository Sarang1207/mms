package com.deesha.pms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.RoleMaster;
import com.deesha.pms.Service.RoleService;


@RestController
@CrossOrigin("*")
public class RoleController {
	 @Autowired
	    private RoleService roleService;

	    @PostMapping
	    @RequestMapping(value="AddRoleDetails")
	    private ResponseEntity addRole(@RequestBody RoleMaster roleMaster) {
	    	System.out.println(roleMaster.toString());
	        Boolean flag = roleService.addRoleService(roleMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdateRoleDetails")
	    private ResponseEntity updateRole(@RequestBody RoleMaster roleMaster) {
	        Boolean flag = roleService.updateRoleService(roleMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeleteRoleDetails")
	    private ResponseEntity deleteRole(@RequestBody RoleMaster roleMaster) {
	        Boolean flag = roleService.deleteRoleService(roleMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getRoleDetails")
	    private ResponseEntity getRole(@RequestBody int rId) {
	    	RoleMaster roleMaster = roleService.getRoleService(rId);
	        if (roleMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllRoleDetails")
	    private List<RoleMaster> getAllRole() {
	    	List<RoleMaster> lstroleMaster = roleService.getAllRoleService();
	    	System.out.println();
	        if (lstroleMaster != null)
	          return lstroleMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}
