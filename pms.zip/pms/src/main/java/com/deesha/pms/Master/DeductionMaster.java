package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tbldeduction")
public class DeductionMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer DeductionId;
private String DeductionName;
private String DeductionDescription;
private String BasicPercent;
public Integer getDeductionId() {
	return DeductionId;
}
public void setDeductionId(Integer deductionId) {
	DeductionId = deductionId;
}
public String getDeductionName() {
	return DeductionName;
}
public void setDeductionName(String deductionName) {
	DeductionName = deductionName;
}
public String getDeductionDescription() {
	return DeductionDescription;
}
public void setDeductionDescription(String deductionDescription) {
	DeductionDescription = deductionDescription;
}
public String getBasicPercent() {
	return BasicPercent;
}
public void setBasicPercent(String basicPercent) {
	BasicPercent = basicPercent;
}
public DeductionMaster() {
	super();
}
public DeductionMaster(Integer deductionId, String deductionName, String deductionDescription, String basicPercent) {
	super();
	DeductionId = deductionId;
	DeductionName = deductionName;
	DeductionDescription = deductionDescription;
	BasicPercent = basicPercent;
}
@Override
public String toString() {
	return "DeductionMaster [DeductionId=" + DeductionId + ", DeductionName=" + DeductionName
			+ ", DeductionDescription=" + DeductionDescription + ", BasicPercent=" + BasicPercent + "]";
}


}
