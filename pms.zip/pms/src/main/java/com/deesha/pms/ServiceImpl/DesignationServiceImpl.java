package com.deesha.pms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.DesignationDAO;
import com.deesha.pms.Master.DesignationMaster;
import com.deesha.pms.Service.DesignationService;


@Service
public class DesignationServiceImpl  implements DesignationService{
	
	@Autowired
	    private DesignationDAO designationDao;
	 
	    public Boolean addDesignationService(DesignationMaster designationMaster) {

	        try{
	        	designationDao.save(designationMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateDesignationService(DesignationMaster designationMaster) {

			 try{
				 designationDao.save(designationMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteDesignationService(DesignationMaster designationMaster) {
			  try{
				  designationDao.delete(designationMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public DesignationMaster getDesignationService(int dId) {
			try{
				DesignationMaster designationMaster = designationDao.findById(dId).get();
	            return designationMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<DesignationMaster> getAllDesignationService() {
			try{
	        	List<DesignationMaster> all = (List<DesignationMaster>) designationDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}