package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tblattendance")
public class AttendanceMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer empId;
private String date;
private String month;
private String year;
private String empAttendance;
public Integer getEmpId() {
	return empId;
}
public void setEmpId(Integer empId) {
	this.empId = empId;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getMonth() {
	return month;
}
public void setMonth(String month) {
	this.month = month;
}
public String getYear() {
	return year;
}
public void setYear(String year) {
	this.year = year;
}
public String getEmpAttendance() {
	return empAttendance;
}
public void setEmpAttendance(String empAttendance) {
	this.empAttendance = empAttendance;
}
public AttendanceMaster() {
	super();
}
public AttendanceMaster(Integer empId, String date, String month, String year, String empAttendance) {
	super();
	this.empId = empId;
	this.date = date;
	this.month = month;
	this.year = year;
	this.empAttendance = empAttendance;
}
@Override
public String toString() {
	return "AttendanceMaster [empId=" + empId + ", date=" + date + ", month=" + month + ", year=" + year
			+ ", empAttendance=" + empAttendance + "]";
}


}
