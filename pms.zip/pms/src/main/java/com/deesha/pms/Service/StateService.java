package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.StateMaster;


public interface StateService {
	public  Boolean addStateService(StateMaster stateMaster);
	public  Boolean updateStateService(StateMaster stateMaster);
	public  Boolean deleteStateService(StateMaster stateMaster);
	public StateMaster getStateService(int sId);
	public List<StateMaster> getAllStateService();
}
