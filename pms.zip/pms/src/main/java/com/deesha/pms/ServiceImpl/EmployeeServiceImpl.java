package com.deesha.pms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.EmployeeDAO;
import com.deesha.pms.Master.EmployeeMaster;
import com.deesha.pms.Service.EmployeeService;


@Service
public class EmployeeServiceImpl  implements EmployeeService{
	
	@Autowired
	    private EmployeeDAO employeeDao;
	 
	    public Boolean addEmployeeService(EmployeeMaster employeeMaster) {

	        try{
	        	employeeDao.save(employeeMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateEmployeeService(EmployeeMaster employeeMaster) {

			 try{
				 employeeDao.save(employeeMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteEmployeeService(EmployeeMaster employeeMaster) {
			  try{
				  employeeDao.delete(employeeMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public EmployeeMaster getEmployeeService(int eId) {
			try{
				EmployeeMaster employeeMaster = employeeDao.findById(eId).get();
	            return employeeMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<EmployeeMaster> getAllEmployeeService() {
			try{
	        	List<EmployeeMaster> all = (List<EmployeeMaster>) employeeDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}