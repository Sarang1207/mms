package com.deesha.pms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.RoleDAO;
import com.deesha.pms.Master.RoleMaster;
import com.deesha.pms.Service.RoleService;


@Service
public class RoleServiceImpl  implements RoleService{
	
	@Autowired
	    private RoleDAO roleDao;
	 
	    public Boolean addRoleService(RoleMaster roleMaster) {

	        try{
	        	roleDao.save(roleMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateRoleService(RoleMaster roleMaster) {

			 try{
				 roleDao.save(roleMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteRoleService(RoleMaster roleMaster) {
			  try{
				  roleDao.delete(roleMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public RoleMaster getRoleService(int rId) {
			try{
				RoleMaster roleMaster = roleDao.findById(rId).get();
	            return roleMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<RoleMaster> getAllRoleService() {
			try{
	        	List<RoleMaster> all = (List<RoleMaster>) roleDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}