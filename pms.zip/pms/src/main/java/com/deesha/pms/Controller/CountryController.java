package com.deesha.pms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.CountryMaster;
import com.deesha.pms.Service.CountryService;

@RestController
@CrossOrigin("*")
public class CountryController {
	 @Autowired
	    private CountryService countryService;

	    @PostMapping
	    @RequestMapping(value="AddCountryDetails")
	    private ResponseEntity addCountry(@RequestBody CountryMaster countryMaster) {
	    	System.out.println(countryMaster.toString());
	        Boolean flag = countryService.addCountryService(countryMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdateCountryDetails")
	    private ResponseEntity updateCountry(@RequestBody CountryMaster countryMaster) {
	        Boolean flag = countryService.updateCountryService(countryMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeleteCountryDetails")
	    private ResponseEntity deleteCountry(@RequestBody CountryMaster countryMaster) {
	        Boolean flag = countryService.deleteCountryService(countryMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getCountryDetails")
	    private ResponseEntity getCountry(@RequestBody int cId) {
	    	CountryMaster countryMaster = countryService.getCountryService(cId);
	        if (countryMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllCountryDetails")
	    private List<CountryMaster> getAllCountry() {
	    	List<CountryMaster> lstcountryMaster = countryService.getAllCountryService();
	    	System.out.println();
	        if (lstcountryMaster != null)
	          return lstcountryMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}
