package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tblleaverecord")
public class LeaveRecordMaster {
@Id
@GeneratedValue(strategy =GenerationType.AUTO)
private Integer empId;
private String leaveDate;
private String leaveReason;
private String leaveStatus;
private String leaveApprovedDate;
public Integer getEmpId() {
	return empId;
}
public void setEmpId(Integer empId) {
	this.empId = empId;
}
public String getLeaveDate() {
	return leaveDate;
}
public void setLeaveDate(String leaveDate) {
	this.leaveDate = leaveDate;
}
public String getLeaveReason() {
	return leaveReason;
}
public void setLeaveReason(String leaveReason) {
	this.leaveReason = leaveReason;
}
public String getLeaveStatus() {
	return leaveStatus;
}
public void setLeaveStatus(String leaveStatus) {
	this.leaveStatus = leaveStatus;
}
public String getLeaveApprovedDate() {
	return leaveApprovedDate;
}
public void setLeaveApprovedDate(String leaveApprovedDate) {
	this.leaveApprovedDate = leaveApprovedDate;
}
public LeaveRecordMaster() {
	super();
}
public LeaveRecordMaster(Integer empId, String leaveDate, String leaveReason, String leaveStatus,
		String leaveApprovedDate) {
	super();
	this.empId = empId;
	this.leaveDate = leaveDate;
	this.leaveReason = leaveReason;
	this.leaveStatus = leaveStatus;
	this.leaveApprovedDate = leaveApprovedDate;
}
@Override
public String toString() {
	return "LeaveRecordMaster [empId=" + empId + ", leaveDate=" + leaveDate + ", leaveReason=" + leaveReason
			+ ", leaveStatus=" + leaveStatus + ", leaveApprovedDate=" + leaveApprovedDate + "]";
}


}
