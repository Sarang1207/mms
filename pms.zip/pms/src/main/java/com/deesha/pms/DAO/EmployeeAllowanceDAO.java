package com.deesha.pms.DAO;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.deesha.pms.Master.EmployeeAllowanceMaster;
@Repository
public interface EmployeeAllowanceDAO extends CrudRepository<EmployeeAllowanceMaster,Integer> {

}
