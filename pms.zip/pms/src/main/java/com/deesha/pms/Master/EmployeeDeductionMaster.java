package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tblemployeededuction")
public class EmployeeDeductionMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer EmpId;
private String DeductionId;
private String Amount;
public Integer getEmpId() {
	return EmpId;
}
public void setEmpId(Integer empId) {
	EmpId = empId;
}
public String getDeductionId() {
	return DeductionId;
}
public void setDeductionId(String deductionId) {
	DeductionId = deductionId;
}
public String getAmount() {
	return Amount;
}
public void setAmount(String amount) {
	Amount = amount;
}
public EmployeeDeductionMaster() {
	super();
}
public EmployeeDeductionMaster(Integer empId, String deductionId, String amount) {
	super();
	EmpId = empId;
	DeductionId = deductionId;
	Amount = amount;
}
@Override
public String toString() {
	return "EmployeeDeductionMaster [EmpId=" + EmpId + ", DeductionId=" + DeductionId + ", Amount=" + Amount + "]";
}


}
