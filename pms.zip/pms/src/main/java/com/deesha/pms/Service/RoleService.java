package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.RoleMaster;

public interface RoleService {
	public  Boolean addRoleService(RoleMaster roleMaster);
	public  Boolean updateRoleService(RoleMaster roleMaster);
	public  Boolean deleteRoleService(RoleMaster roleMaster);
	public RoleMaster getRoleService(int rId);
	public List<RoleMaster> getAllRoleService();
}
