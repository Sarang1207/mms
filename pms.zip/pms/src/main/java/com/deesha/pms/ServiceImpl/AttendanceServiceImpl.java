package com.deesha.pms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.AttendanceDAO;
import com.deesha.pms.Master.AttendanceMaster;
import com.deesha.pms.Service.AttendanceService;


@Service
public class AttendanceServiceImpl  implements AttendanceService{
	
	@Autowired
	    private AttendanceDAO attendanceDao;
	 
	    public Boolean addAttendanceService(AttendanceMaster attendanceMaster) {

	        try{
	        	attendanceDao.save(attendanceMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateAttendanceService(AttendanceMaster attendanceMaster) {

			 try{
				 attendanceDao.save(attendanceMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteAttendanceService(AttendanceMaster attendanceMaster) {
			  try{
				  attendanceDao.delete(attendanceMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public AttendanceMaster getAttendanceService(int aId) {
			try{
				AttendanceMaster attendanceMaster = attendanceDao.findById(aId).get();
	            return attendanceMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<AttendanceMaster> getAllAttendanceService() {
			try{
	        	List<AttendanceMaster> all = (List<AttendanceMaster>) attendanceDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}