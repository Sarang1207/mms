package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.DepartmentMaster;

public interface DepartmentService {
	public  Boolean addDepartmentService(DepartmentMaster departmentMaster);
	public  Boolean updateDepartmentService(DepartmentMaster departmentMaster);
	public  Boolean deleteDepartmentService(DepartmentMaster departmentMaster);
	public DepartmentMaster getDepartmentService(int dId);
	public List<DepartmentMaster> getAllDepartmentService();
}
