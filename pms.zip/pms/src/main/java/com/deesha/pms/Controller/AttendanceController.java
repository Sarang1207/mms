package com.deesha.pms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.AttendanceMaster;
import com.deesha.pms.Service.AttendanceService;

@RestController
@CrossOrigin("*")
public class AttendanceController {
	 @Autowired
	    private AttendanceService attendanceService;

	    @PostMapping
	    @RequestMapping(value="AddAttendanceDetails")
	    private ResponseEntity addAttendance(@RequestBody AttendanceMaster attendanceMaster) {
	    	System.out.println(attendanceMaster.toString());
	        Boolean flag = attendanceService.addAttendanceService(attendanceMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdateAttendanceDetails")
	    private ResponseEntity updateAttendance(@RequestBody AttendanceMaster attendanceMaster) {
	        Boolean flag = attendanceService.updateAttendanceService(attendanceMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeleteAttendanceDetails")
	    private ResponseEntity deleteAttendance(@RequestBody AttendanceMaster attendanceMaster) {
	        Boolean flag = attendanceService.deleteAttendanceService(attendanceMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getAttendanceDetails")
	    private ResponseEntity getAttendance(@RequestBody int aId) {
	    	AttendanceMaster attendanceMaster = attendanceService.getAttendanceService(aId);
	        if (attendanceMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllAttendanceDetails")
	    private List<AttendanceMaster> getAllAttendance() {
	    	List<AttendanceMaster> lstattendanceMaster = attendanceService.getAllAttendanceService();
	    	System.out.println();
	        if (lstattendanceMaster != null)
	          return lstattendanceMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}
