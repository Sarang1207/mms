package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tblemployeeallowance")
public class EmployeeAllowanceMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer EmpId; 
private String AllowanceId;
private String Amount;
public Integer getEmpId() {
	return EmpId;
}
public void setEmpId(Integer empId) {
	EmpId = empId;
}
public String getAllowanceId() {
	return AllowanceId;
}
public void setAllowanceId(String allowanceId) {
	AllowanceId = allowanceId;
}
public String getAmount() {
	return Amount;
}
public void setAmount(String amount) {
	Amount = amount;
}
public EmployeeAllowanceMaster() {
	super();
}
public EmployeeAllowanceMaster(Integer empId, String allowanceId, String amount) {
	super();
	EmpId = empId;
	AllowanceId = allowanceId;
	Amount = amount;
}
@Override
public String toString() {
	return "EmployeeAllowanceMaster [EmpId=" + EmpId + ", AllowanceId=" + AllowanceId + ", Amount=" + Amount + "]";
}


}
