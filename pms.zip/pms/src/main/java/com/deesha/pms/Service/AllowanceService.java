package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.AllowanceMaster;

public interface AllowanceService {
	public  Boolean addAllowanceService(AllowanceMaster allowanceMaster);
	public  Boolean updateAllowanceService(AllowanceMaster allowanceMaster);
	public  Boolean deleteAllowanceService(AllowanceMaster allowanceMaster);
	public AllowanceMaster getAllowanceService(int aId);
	public List<AllowanceMaster> getAllAllowanceService();
}
