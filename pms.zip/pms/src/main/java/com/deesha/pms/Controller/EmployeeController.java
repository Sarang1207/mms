package com.deesha.pms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.EmployeeMaster;
import com.deesha.pms.Service.EmployeeService;

@RestController
@CrossOrigin("*")
public class EmployeeController {
	 @Autowired
	    private EmployeeService employeeService;

	    @PostMapping
	    @RequestMapping(value="AddEmployeeDetails")
	    private ResponseEntity addEmployee(@RequestBody EmployeeMaster employeeMaster) {
	    	System.out.println(employeeMaster.toString());
	        Boolean flag = employeeService.addEmployeeService(employeeMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdateEmployeeDetails")
	    private ResponseEntity updateEmployee(@RequestBody EmployeeMaster employeeMaster) {
	        Boolean flag = employeeService.updateEmployeeService(employeeMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeleteEmployeeDetails")
	    private ResponseEntity deleteEmployee(@RequestBody EmployeeMaster employeeMaster) {
	        Boolean flag = employeeService.deleteEmployeeService(employeeMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getEmployeeDetails")
	    private ResponseEntity getEmployee(@RequestBody int eId) {
	    	EmployeeMaster employeeMaster = employeeService.getEmployeeService(eId);
	        if (employeeMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllEmployeeDetails")
	    private List<EmployeeMaster> getAllEmployee() {
	    	List<EmployeeMaster> lstemployeeMaster = employeeService.getAllEmployeeService();
	    	System.out.println();
	        if (lstemployeeMaster != null)
	          return lstemployeeMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}
