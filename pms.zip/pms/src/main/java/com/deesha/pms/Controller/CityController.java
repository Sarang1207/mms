package com.deesha.pms.Controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.CityMaster;
import com.deesha.pms.Service.CityService;
@RestController
@CrossOrigin("*")
public class CityController {
	 @Autowired
	    private CityService cityService;

	    @PostMapping
	    @RequestMapping(value="AddCityDetails")
	    private ResponseEntity addCity(@RequestBody CityMaster cityMaster) {
	    	System.out.println(cityMaster.toString());
	        Boolean flag = cityService.addCityService(cityMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdateCityDetails")
	    private ResponseEntity updateCity(@RequestBody CityMaster cityMaster) {
	        Boolean flag = cityService.updateCityService(cityMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeleteCityDetails")
	    private ResponseEntity deleteCity(@RequestBody CityMaster cityMaster) {
	        Boolean flag = cityService.deleteCityService(cityMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getCityDetails")
	    private ResponseEntity getCountry(@RequestBody int cId) {
	    	CityMaster cityMaster = cityService.getCityService(cId);
	        if (cityMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllCityDetails")
	    private List<CityMaster> getAllCity() {
	    	List<CityMaster> lstcityMaster = cityService.getAllCityService();
	    	System.out.println();
	        if (lstcityMaster != null)
	          return lstcityMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}
