package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tblallowance")
public class AllowanceMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer AllowanceId;
private String AllowanceName;
private String  AllowanceDescription; 
private String BasicPercent;
public Integer getAllowanceId() {
	return AllowanceId;
}
public void setAllowanceId(Integer allowanceId) {
	AllowanceId = allowanceId;
}
public String getAllowanceName() {
	return AllowanceName;
}
public void setAllowanceName(String allowanceName) {
	AllowanceName = allowanceName;
}
public String getAllowanceDescription() {
	return AllowanceDescription;
}
public void setAllowanceDescription(String allowanceDescription) {
	AllowanceDescription = allowanceDescription;
}
public String getBasicPercent() {
	return BasicPercent;
}
public void setBasicPercent(String basicPercent) {
	BasicPercent = basicPercent;
}
public AllowanceMaster() {
	super();
}
public AllowanceMaster(Integer allowanceId, String allowanceName, String allowanceDescription, String basicPercent) {
	super();
	AllowanceId = allowanceId;
	AllowanceName = allowanceName;
	AllowanceDescription = allowanceDescription;
	BasicPercent = basicPercent;
}
@Override
public String toString() {
	return "AllowanceMaster [AllowanceId=" + AllowanceId + ", AllowanceName=" + AllowanceName
			+ ", AllowanceDescription=" + AllowanceDescription + ", BasicPercent=" + BasicPercent + "]";
}


}
