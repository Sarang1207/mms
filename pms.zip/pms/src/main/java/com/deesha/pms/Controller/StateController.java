package com.deesha.pms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.StateMaster;
import com.deesha.pms.Service.StateService;

@RestController
@CrossOrigin("*")
public class StateController {
	 @Autowired
	    private StateService stateService;

	    @PostMapping
	    @RequestMapping(value="AddStateDetails")
	    private ResponseEntity addState(@RequestBody StateMaster stateMaster) {
	    	System.out.println(stateMaster.toString());
	        Boolean flag = stateService.addStateService(stateMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdateStateDetails")
	    private ResponseEntity updateState(@RequestBody StateMaster stateMaster) {
	        Boolean flag = stateService.updateStateService(stateMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeleteStateDetails")
	    private ResponseEntity deleteState(@RequestBody StateMaster stateMaster) {
	        Boolean flag = stateService.deleteStateService(stateMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getStateDetails")
	    private ResponseEntity getState(@RequestBody int sId) {
	    	StateMaster stateMaster = stateService.getStateService(sId);
	        if (stateMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllStateDetails")
	    private List<StateMaster> getAllState() {
	    	List<StateMaster> lststateMaster = stateService.getAllStateService();
	    	System.out.println();
	        if (lststateMaster != null)
	          return lststateMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}

