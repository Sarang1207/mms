package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.DeductionMaster;

public interface DeductionService {
	public  Boolean addDeductionService(DeductionMaster deductionMaster);
	public  Boolean updateDeductionService(DeductionMaster deductionMaster);
	public  Boolean deleteDeductionService(DeductionMaster deductionMaster);
	public DeductionMaster getDeductionService(int dId);
	public List<DeductionMaster> getAllDeductionService();
}
