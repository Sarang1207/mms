package com.deesha.pms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.PublicHolidayCalendarMaster;
import com.deesha.pms.Service.PublicHolidayCalendarService;

@RestController
@CrossOrigin("*")
public class PublicHolidayCalendarController {
	 @Autowired
	    private PublicHolidayCalendarService publicholidaycalendarService;

	    @PostMapping
	    @RequestMapping(value="AddPublicHolidayCalendarDetails")
	    private ResponseEntity addPublicHolidayCalendar(@RequestBody PublicHolidayCalendarMaster publicholidaycalendarMaster) {
	    	System.out.println(publicholidaycalendarMaster.toString());
	        Boolean flag = publicholidaycalendarService.addPublicHolidayCalendarService(publicholidaycalendarMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdatePublicHolidayCalendarDetails")
	    private ResponseEntity updatePublicHolidayCalendar(@RequestBody PublicHolidayCalendarMaster publicholidaycalendarMaster) {
	        Boolean flag = publicholidaycalendarService.updatePublicHolidayCalendarService(publicholidaycalendarMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeletePublicHolidayCalendarDetails")
	    private ResponseEntity deletePublicHolidayCalendar(@RequestBody PublicHolidayCalendarMaster publicholidaycalendarMaster) {
	        Boolean flag = publicholidaycalendarService.deletePublicHolidayCalendarService(publicholidaycalendarMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getPublicHolidayCalendarDetails")
	    private ResponseEntity getPublicHolidayCalendar(@RequestBody int pId) {
	    	PublicHolidayCalendarMaster publicholidaycalendarMaster = publicholidaycalendarService.getPublicHolidayCalendarService(pId);
	        if (publicholidaycalendarMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllPublicHolidayCalendarDetails")
	    private List<PublicHolidayCalendarMaster> getAllPublicHolidayCalendar() {
	    	List<PublicHolidayCalendarMaster> lstpublicholidaycalendarMaster = publicholidaycalendarService.getAllPublicHolidayCalendarService();
	    	System.out.println();
	        if (lstpublicholidaycalendarMaster != null)
	          return lstpublicholidaycalendarMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}
