package com.deesha.pms.ServiceImpl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.CountryDAO;
import com.deesha.pms.Master.CountryMaster;
import com.deesha.pms.Service.CountryService;


@Service
public class CountryServiceImpl  implements CountryService{
	
	@Autowired
	    private CountryDAO countryDao;
	 
	    public Boolean addCountryService(CountryMaster countryMaster) {

	        try{
	        	countryDao.save(countryMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateCountryService(CountryMaster countryMaster) {

			 try{
				 countryDao.save(countryMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteCountryService(CountryMaster countryMaster) {
			  try{
				  countryDao.delete(countryMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public CountryMaster getCountryService(int cId) {
			try{
				CountryMaster countryMaster = countryDao.findById(cId).get();
	            return countryMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<CountryMaster> getAllCountryService() {
			try{
	        	List<CountryMaster> all = (List<CountryMaster>) countryDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}