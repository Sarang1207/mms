package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.EmployeeAllowanceMaster;

public interface EmployeeAllowanceService {
	public  Boolean addEmployeeAllowanceService(EmployeeAllowanceMaster employeeallowanceMaster);
	public  Boolean updateEmployeeAllowanceService(EmployeeAllowanceMaster employeeallowanceMaster);
	public  Boolean deleteEmployeeAllowanceService(EmployeeAllowanceMaster employeeallowanceMaster);
	public EmployeeAllowanceMaster getEmployeeAllowanceService(int eId);
	public List<EmployeeAllowanceMaster> getAllEmployeeAllowanceService();
}
