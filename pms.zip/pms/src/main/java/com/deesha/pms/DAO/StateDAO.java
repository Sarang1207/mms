package com.deesha.pms.DAO;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.deesha.pms.Master.StateMaster;
@Repository
public interface StateDAO extends CrudRepository<StateMaster,Integer> {

}
