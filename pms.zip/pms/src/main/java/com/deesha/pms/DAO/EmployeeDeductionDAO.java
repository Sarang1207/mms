package com.deesha.pms.DAO;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.deesha.pms.Master.EmployeeDeductionMaster;
@Repository
public interface EmployeeDeductionDAO extends CrudRepository<EmployeeDeductionMaster,Integer> {

}
