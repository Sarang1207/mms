package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tblrole")
public class RoleMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)

private Integer RoleId;
private String RoleName;
private String RoleDesciption;
public Integer getRoleId() {
	return RoleId;
}
public void setRoleId(Integer roleId) {
	RoleId = roleId;
}
public String getRoleName() {
	return RoleName;
}
public void setRoleName(String roleName) {
	RoleName = roleName;
}
public String getRoleDesciption() {
	return RoleDesciption;
}
public void setRoleDesciption(String roleDesciption) {
	RoleDesciption = roleDesciption;
}
public RoleMaster() {
	super();
}
public RoleMaster(Integer roleId, String roleName, String roleDesciption) {
	super();
	RoleId = roleId;
	RoleName = roleName;
	RoleDesciption = roleDesciption;
}
@Override
public String toString() {
	return "RoleMaster [RoleId=" + RoleId + ", RoleName=" + RoleName + ", RoleDesciption=" + RoleDesciption + "]";
}


}
