package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.LeaveRecordMaster;

public interface LeaveRecordService {
	public  Boolean addLeaveRecordService(LeaveRecordMaster leaveRecordMaster);
	public  Boolean updateLeaveRecordService(LeaveRecordMaster leaveRecordMaster);
	public  Boolean deleteLeaveRecordService(LeaveRecordMaster leaveRecordMaster);
	public LeaveRecordMaster getLeaveRecordService(int lId);
	public List<LeaveRecordMaster> getAllLeaveRecordService();
}
