package com.deesha.pms.Service;

import java.util.List;

import com.deesha.pms.Master.AttendanceMaster;

public interface AttendanceService {
	public  Boolean addAttendanceService(AttendanceMaster attendanceMaster);
	public  Boolean updateAttendanceService(AttendanceMaster attendanceMaster);
	public  Boolean deleteAttendanceService(AttendanceMaster attendanceMaster);
	public AttendanceMaster getAttendanceService(int aId);
	public List<AttendanceMaster> getAllAttendanceService();
}
