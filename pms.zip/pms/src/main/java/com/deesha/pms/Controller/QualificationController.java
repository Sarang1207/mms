package com.deesha.pms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deesha.pms.Master.QualificationMaster;
import com.deesha.pms.Service.QualificationService;


@RestController
@CrossOrigin("*")
public class QualificationController {
	 @Autowired
	    private QualificationService qualificationService;

	    @PostMapping
	    @RequestMapping(value="AddQualificationDetails")
	    private ResponseEntity addQualification(@RequestBody QualificationMaster qualificationMaster) {
	    	System.out.println(qualificationMaster.toString());
	        Boolean flag = qualificationService.addQualificationService(qualificationMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @PutMapping
	    @RequestMapping(value="UpdateQualificationDetails")
	    private ResponseEntity updateQualification(@RequestBody QualificationMaster qualificationMaster) {
	        Boolean flag = qualificationService.updateQualificationService(qualificationMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @DeleteMapping
	    @RequestMapping(value="DeleteQualificationDetails")
	    private ResponseEntity deleteQualification(@RequestBody QualificationMaster qualificationMaster) {
	        Boolean flag = qualificationService.deleteQualificationService(qualificationMaster);
	        if (flag)

	            return new ResponseEntity(flag, HttpStatus.OK);
	        else
	            return new ResponseEntity(flag, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	    @GetMapping
	    @RequestMapping(value="getQualificationDetails")
	    private ResponseEntity getCountry(@RequestBody int qId) {
	    	QualificationMaster qualificationMaster = qualificationService.getQualificationService(qId);
	        if (qualificationMaster != null)
	            return new ResponseEntity(true, HttpStatus.OK);
	        else
	            return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    @GetMapping
	    @RequestMapping(value="getAllQualificationDetails")
	    private List<QualificationMaster> getAllQualification() {
	    	List<QualificationMaster> lstqualificationMaster = qualificationService.getAllQualificationService();
	    	System.out.println();
	        if (lstqualificationMaster != null)
	          return lstqualificationMaster; // return new ResponseEntity(true, HttpStatus.OK);
	        else
	          return null; // return new ResponseEntity(false, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}

