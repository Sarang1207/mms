package com.deesha.pms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deesha.pms.DAO.EmployeeDeductionDAO;
import com.deesha.pms.Master.EmployeeDeductionMaster;
import com.deesha.pms.Service.EmployeeDeductionService;


@Service
public class EmployeeDeductionServiceImpl  implements EmployeeDeductionService{
	
	@Autowired
	    private EmployeeDeductionDAO employeedeductionDao;
	 
	    public Boolean addEmployeeDeductionService(EmployeeDeductionMaster employeedeductionMaster) {

	        try{
	        	employeedeductionDao.save(employeedeductionMaster);
	            return true;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return false;
	        }
	    }

		public Boolean updateEmployeeDeductionService(EmployeeDeductionMaster employeedeductionMaster) {

			 try{
				 employeedeductionDao.save(employeedeductionMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public Boolean deleteEmployeeDeductionService(EmployeeDeductionMaster employeedeductionMaster) {
			  try{
				  employeedeductionDao.delete(employeedeductionMaster);
		            return true;
		        }
		        catch(Exception e)
		        {
		            e.printStackTrace();
		            return false;
		        }
		}

		public EmployeeDeductionMaster getEmployeeDeductionService(int eId) {
			try{
				EmployeeDeductionMaster employeedeductionMaster = employeedeductionDao.findById(eId).get();
	            return employeedeductionMaster;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}

		public List<EmployeeDeductionMaster> getAllEmployeeDeductionService() {
			try{
	        	List<EmployeeDeductionMaster> all = (List<EmployeeDeductionMaster>) employeedeductionDao.findAll();
	            return all;
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	            return null;
	        }
		}


}