package com.deesha.pms.Master;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tblqualification")
public class QualificationMaster {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer qualId;
private String qualName;
private String qualDescription;
public Integer getQualId() {
	return qualId;
}
public void setQualId(Integer qualId) {
	this.qualId = qualId;
}
public String getQualName() {
	return qualName;
}
public void setQualName(String qualName) {
	this.qualName = qualName;
}
public String getQualDescription() {
	return qualDescription;
}
public void setQualDescription(String qualDescription) {
	this.qualDescription = qualDescription;
}
public QualificationMaster() {
	super();
}
public QualificationMaster(Integer qualId, String qualName, String qualDescription) {
	super();
	this.qualId = qualId;
	this.qualName = qualName;
	this.qualDescription = qualDescription;
}
@Override
public String toString() {
	return "QualificationMaster [qualId=" + qualId + ", qualName=" + qualName + ", qualDescription=" + qualDescription
			+ "]";
}


}
